// TODO: Create 4-String variables to introduce develop your story.
// YOUR CODE GOES HERE


// TODO: Create 3-String variables to set the time period of your story or discuss other number elements.
// YOUR CODE GOES HERE


// TODO: Create 1-Array variable to show a collection of items your character might have.
// YOUR CODE GOES HERE


// TODO: Create 1-Boolean variable to demonstrate a true or false scenario.
// YOUR CODE GOES HERE


// TODO: Print your story to the console.
// YOUR CODE GOES HERE
